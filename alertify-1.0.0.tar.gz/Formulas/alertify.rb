class Alertify < Formula
  desc "CLI tool for managing reminders"
  homepage "https://github.com/amoghrrathod/alertify.c"
  url "https://github.com/amoghrrathod/alertify.c/archive/v1.0.0.tar.gz"
  sha256 "your_tarball_sha256_here"

  depends_on "jansson"
  depends_on "uuid"

  def install
    system "make", "install", "PREFIX=#{prefix}"
  end

  test do
    system "#{bin}/alertify", "--version"
  end
end
